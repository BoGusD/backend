// @ts-check

import Animal from './animals.js';

const ani = new Animal();
console.log(ani);
ani.showAnimals();
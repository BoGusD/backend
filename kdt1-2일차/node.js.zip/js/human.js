// @ts-check

const human = ['철수', '영희'];

function showName() {
    human.map((name) => console.log(name));
}

export {human, showName};
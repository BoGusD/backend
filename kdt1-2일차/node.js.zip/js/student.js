// @ts-check

import { human, showName } from './human.js';

showName();
